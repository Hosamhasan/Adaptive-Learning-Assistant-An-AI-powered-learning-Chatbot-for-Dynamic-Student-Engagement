-- =============================================================================
-- Seed Data for Testing & Verification
-- =============================================================================

-- Insert sample students
INSERT INTO students (name, grade, group_name, code, telegram_id, telegram_name, active, linked_at)
VALUES 
('أحمد محمود علي', 'الصف الثالث الثانوي', 'مجموعة الكيمياء A', 'STU-1001', 123456789, 'ahmed_chem', true, NOW()),
('سارة إبراهيم حسن', 'الصف الثالث الثانوي', 'مجموعة الكيمياء B', 'STU-1002', NULL, NULL, true, NULL),
('عمر خالد مصطفى', 'الصف الثالث الثانوي', 'مجموعة الكيمياء A', 'STU-1003', NULL, NULL, true, NULL)
ON CONFLICT (code) DO NOTHING;

-- Insert sample homework
INSERT INTO homework (code, title, lesson, total_marks, image_url, questions, answer_key, rubric, active)
VALUES 
(
    'HW1', 
    'واجب الباب الأول - العناصر الانتقالية', 
    'العناصر الانتقالية واستخداماتها', 
    20.0, 
    'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=600&q=80',
    '1. اذكر الأهمية الاقتصادية لعنصر السكانديوم مع الألومنيوم.
2. فسر: يشذ التركيب الإلكتروني لكل من الكروم والنحاس.
3. ما هي الخواص المغناطيسية لأيون Fe3+؟',
    '[فكرة: سبائك السكانديوم] طائرات الميج المقاتلة لخفتها وصلابتها العالية.
[فكرة: التوزيع الإلكتروني الشاذ] الامتلاء النصفي للكروم (3d5 4s1) والامتلاء التام للنحاس (3d10 4s1) لتحقيق استقرار ذري أعلى.
[فكرة: العزم المغناطيسي والبارامغناطيسية] بارامغناطيسي لوجود 5 إلكترونات مفردة في المستوى الفرعي d.',
    'س1: 5 درجات
س2: 8 درجات
س3: 7 درجات (يراعى ذكر الخطوات والتعليل العلمي)',
    true
)
ON CONFLICT (code) DO NOTHING;

-- Insert sample mistakes for adaptive testing
INSERT INTO mistakes (telegram_id, homework_code, question, idea, lesson, correction)
VALUES 
(123456789, 'HW1', 'س2', 'التوزيع الإلكتروني الشاذ للكروم', 'العناصر الانتقالية', 'التوزيع الصحيح Cr: [Ar] 4s1 3d5 وليس 4s2 3d4'),
(123456789, 'HW1', 'س3', 'حساب العزم المغناطيسي لأيونات الحديد', 'العناصر الانتقالية', 'أيون Fe3+ يحتوي على 5 إلكترونات مفردة في 3d وليس 4')
ON CONFLICT DO NOTHING;
