-- =============================================================================
-- Adaptive Learning System - PostgreSQL Relational Database Schema
-- Project: MCIT / DB Industry Graduation Project
-- =============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- -----------------------------------------------------------------------------
-- 1. Table: students
-- Stores enrolled student records and links them to Telegram accounts.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
    id SERIAL PRIMARY KEY,
    telegram_id BIGINT UNIQUE,
    telegram_name VARCHAR(255),
    name VARCHAR(255) NOT NULL,
    grade VARCHAR(100) DEFAULT '3rd Secondary',
    group_name VARCHAR(100) DEFAULT 'Group A',
    code VARCHAR(50) UNIQUE NOT NULL,
    active BOOLEAN DEFAULT TRUE,
    linked_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_students_telegram_id ON students(telegram_id);
CREATE INDEX IF NOT EXISTS idx_students_code ON students(UPPER(TRIM(code)));

-- -----------------------------------------------------------------------------
-- 2. Table: homework
-- Assignments published by the teacher with answer keys and evaluation rubrics.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS homework (
    id SERIAL PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    lesson VARCHAR(255),
    total_marks NUMERIC(5, 2) NOT NULL DEFAULT 20.0,
    image_url TEXT,
    questions TEXT,
    answer_key TEXT,
    rubric TEXT,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_homework_active_code ON homework(active, UPPER(code));

-- -----------------------------------------------------------------------------
-- 3. Table: submissions
-- Student homework submissions, evaluation results, scores, and review status.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS submissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    telegram_id BIGINT NOT NULL REFERENCES students(telegram_id) ON DELETE CASCADE,
    homework_code VARCHAR(50) NOT NULL REFERENCES homework(code) ON DELETE CASCADE,
    score NUMERIC(5, 2) NOT NULL DEFAULT 0.0,
    total NUMERIC(5, 2) NOT NULL DEFAULT 20.0,
    status VARCHAR(50) NOT NULL DEFAULT 'graded', -- 'graded', 'needs_review', 'unreadable', 'error'
    needs_review BOOLEAN DEFAULT FALSE,
    feedback TEXT,
    file_id TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_submissions_telegram_id ON submissions(telegram_id);
CREATE INDEX IF NOT EXISTS idx_submissions_status ON submissions(status);

-- -----------------------------------------------------------------------------
-- 4. Table: mistakes
-- Knowledge gaps and errors identified from both homework and adaptive quizzes.
-- Powers the adaptive recommendation and targeted practice engine.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mistakes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    submission_id UUID REFERENCES submissions(id) ON DELETE SET NULL,
    telegram_id BIGINT NOT NULL REFERENCES students(telegram_id) ON DELETE CASCADE,
    homework_code VARCHAR(50) NOT NULL, -- e.g., 'HW1', 'HW2', or 'QUIZ'
    question VARCHAR(100),
    idea VARCHAR(255),                  -- The specific tested concept/idea
    lesson VARCHAR(255),                -- Curriculum lesson title
    correction TEXT,                    -- Model correction guidance
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_mistakes_telegram_idea ON mistakes(telegram_id, idea);
CREATE INDEX IF NOT EXISTS idx_mistakes_created_at ON mistakes(created_at DESC);

-- -----------------------------------------------------------------------------
-- 5. Table: quiz_sessions
-- Real-time interactive quiz sessions generated adaptively by Gemini LLM.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS quiz_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    telegram_id BIGINT NOT NULL REFERENCES students(telegram_id) ON DELETE CASCADE,
    topic VARCHAR(255) NOT NULL,
    questions JSONB NOT NULL,           -- Array of generated multiple-choice questions
    total INT NOT NULL DEFAULT 5,
    answers JSONB DEFAULT '[]'::jsonb,  -- Array of student answers: [{"i": 0, "c": 2, "ok": true}]
    score INT NOT NULL DEFAULT 0,
    finished BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_quiz_sessions_telegram ON quiz_sessions(telegram_id);
