-- =============================================================================
-- Supabase / pgvector Vector Store Configuration for Curriculum RAG
-- Project: MCIT / DB Industry Graduation Project
-- =============================================================================

-- Enable the pgvector extension to work with embedding vectors
CREATE EXTENSION IF NOT EXISTS vector;

-- -----------------------------------------------------------------------------
-- Table: documents
-- Stores curriculum text chunks, metadata, and embeddings (Google Gemini Embeddings: 768 dims)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS documents (
    id BIGSERIAL PRIMARY KEY,
    content TEXT NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    embedding VECTOR(768)
);

-- Create an HNSW index on the embedding vector for fast cosine similarity search
CREATE INDEX IF NOT EXISTS documents_embedding_hnsw_idx 
ON documents USING hnsw (embedding vector_cosine_ops);

-- -----------------------------------------------------------------------------
-- Function: match_documents
-- RPC function invoked by n8n / LangChain Supabase Vector Store
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION match_documents (
    query_embedding VECTOR(768),
    match_count INT DEFAULT 6,
    filter JSONB DEFAULT '{}'::jsonb
) RETURNS TABLE (
    id BIGINT,
    content TEXT,
    metadata JSONB,
    similarity FLOAT
) LANGUAGE plpgsql AS $$
#variable_conflict use_column
BEGIN
    RETURN QUERY
    SELECT
        documents.id,
        documents.content,
        documents.metadata,
        1 - (documents.embedding <=> query_embedding) AS similarity
    FROM documents
    WHERE documents.metadata @> filter
    ORDER BY documents.embedding <=> query_embedding
    LIMIT match_count;
END;
$$;
