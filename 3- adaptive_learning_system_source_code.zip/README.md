# منظومة التعلم التكيفي الذكية (Adaptive Learning System)

> \*\*مشروع تخرج مسار صناعة قواعد البيانات (DB Industry) - وزارة الاتصالات وتكنولوجيا المعلومات (MCIT)\*\*

\---

## 📖 1. نبذة عن المشروع (Project Overview)

نظام تعليمي ذكي وتفاعلي يهدف لتخصيص عملية التعلم لطلاب مرحلة الثانوية العامة (مادة الكيمياء والعلوم)، من خلال دمج:

1. **تصحيح الواجبات الذكي بالرؤية الحاسوبية (Multimodal AI Grading):** تصحيح أوراق الواجبات المكتوبة بخط اليد بدقة وفق نماذج إجابة وروباريك محدد من المعلم.
2. **محرك تحليل الفجوات المعرفية (Diagnostic Knowledge Gaps Analysis):** رصد أخطاء الطلاب المفاهيمية وتسجيلها تلقائياً.
3. **توليد اختبارات تكيفية موجهة (Adaptive Practice via RAG):** توليد أسئلة مخصصة من محتوى المنهج المعتمد لمعالجة نقاط ضعف كل طالب على حدة.
4. **واجهة تفاعلية عبر تليجرام (Telegram Bot \& Mini App):** تجربة مستخدم سلسة ومباشرة عبر الهاتف المحمول.

\---

## 🛠️ 2. المعمارية والتقنيات المستخدمة (Tech Stack)

* **منصة الأتمتة والـ Backend:** [n8n](https://n8n.io/) (Low-Code Automation Engine).
* **قواعد البيانات:**

  * **PostgreSQL 16:** لتخزين الطلاب، الواجبات، التسليمات، ونقاط الضعف.
  * **pgvector / Supabase:** لتخزين المتجهات الفيكتورية لمحتوى المنهج والبحث الدلالي (RAG).
* **نماذج الذكاء الاصطناعي:**

  * **Google Gemini 1.5 / 2.0 Flash:** للتحليل متعدد الوسائط، وكلاء الحوار (AI Agent)، وتوليد الأسئلة.
  * **Gemini Embeddings:** لإنشاء التضمينات النصية للدروس.
* **التشفير والأمان:** التحقق من تواقيع تليجرام باستخدام **Ed25519 \& SHA-512** المبرمجة بـ JavaScript نقية لضمان الأمان دون الحاجة لمكتبات نظام مقيدة.
* **الواجهة الأمامية (Frontend):** Telegram Mini App (HTML5, Modern CSS3, Vanilla JS).
* **الرسوم البيانية:** QuickChart.io API لتوليد رسومات بيانية ديناميكية للطلاب داخل الشات.

\---

## 📂 3. هيكل المشروع (Repository Structure)

```text
adaptive-learning-system/
├── workflows/                       # مسارات عمل n8n
│   ├── 01\_student\_bot\_workflow.json # سير عمل البوت وتصحيح الواجبات ومحرك الـ RAG
│   └── 02\_adaptive\_learning\_api\_workflow.json # واجهة برمجة التطبيقات (API) للميني آب
│
├── database/                        # كود وقواعد البيانات
│   ├── schema.sql                   # جداول PostgreSQL كاملة والفهارس
│   ├── supabase\_vector.sql          # إعداد pgvector وجدول documents ودالة البحث
│   └── seed\_data.sql                # بيانات تجريبية جاهزة للاختبار
│
├── frontend/                        # واجهة تطبيق التليجرام (Telegram WebApp)
│   ├── index.html                   # واجهة الطالب ولوحة التحكم
│   ├── style.css                    # تصميم متجاوب داكن مريح للعين
│   └── app.js                       # منطق الاتصال بـ API الاختبارات التكيفية
│
├── docker/                          # أدوات التشغيل السريع
│   ├── docker-compose.yml           # تشغيل PostgreSQL مع pgvector و n8n
│   └── .env.example                 # نموذج إعداد المتغيرات البيئية
│
├── docs/                            # التوثيق الفني المفصل
│   ├── architecture.md              # شرح تفصيلي لمعمارية الحلقات التكيفية
│   └── api\_spec.md                  # توثيق مدخلات ومخرجات الـ API
│
└── README.md                        # هذا الملف التوضيحي
```

\---

## 🚀 4. خطوات التشغيل السريع (Quick Start Guide)

### المتطلبات المسبقة:

* [Docker](https://www.docker.com/) \& Docker Compose مثبتين على الجهاز.
* حساب ومفتاح API من [Google AI Studio](https://aistudio.google.com/).
* بوت تليجرام من [BotFather](https://t.me/BotFather).

### الخطوات:

1. **استنساخ المستودع والدخول للمجلد:**

```bash
   cd adaptive-learning-system/docker
   ```

2. **ضبط المتغيرات البيئية:**
انسخ ملف `.env.example` إلى `.env` وضع مفاتيحك الخاصة:

```bash
   cp .env.example .env
   ```

3. **تشغيل الحاويات (Postgres + n8n):**

```bash
   docker compose up -d
   ```

   سيتم تلقائياً إنشاء الجداول في قاعدة البيانات وتفعيل ملحق `pgvector`.

4. **استيراد مسارات العمل في n8n:**

   * افتح المتصفح على: `http://localhost:5678`
   * أنشئ حساب المشرف.
   * من القائمة اختر **Import from File** واستورد الملفين الموجودين في مجلد `workflows/`.
   * قم بتفعيل مسارات العمل (Active: ON).
5. **رفع المنهج وبدء التدريب:**

   * عبر رابط الفورم الخاص بالبوت: ارفع ملفات المنهج PDF ليتم تقسيمها وتضمينها فوراً في الفيكتور داتا بيز.

\---

## 👥 فريق العمل والإشراف

* **المشروع:** نظام التعلم التكيفي (Adaptive Learning System)
* Associate Prof. Hosam Hasan Abdelhady Ibrahim
* Dr. Omnia Reda Ghalwash
* Mr. Mohammed Hussien 
* Mrs. Doaa ElGanzoury
* **المبادرة:** مبادرة رواد مصر الرقميةDEPI Industry)
* **الجهة الراعية:** وزارة الاتصالات وتكنولوجيا المعلومات (MCIT) - جمهورية مصر العربية.

