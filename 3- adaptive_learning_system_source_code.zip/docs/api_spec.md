# API Specification: Mini App Webhook (`/ala-api`)

## Endpoint
- **URL**: `POST /webhook/ala-api`
- **Content-Type**: `application/json`

---

## 1. Action: `me` (Student Profile & Analytics)
Retrieves student personal details, recent homework grades, quiz accuracy, and top 5 weak points.

### Request Body
```json
{
  "payload": {
    "initData": "query_id=...&user=...&signature=...",
    "action": "me"
  }
}
```

### Response
```json
{
  "ok": true,
  "name": "أحمد محمود علي",
  "grade": "الصف الثالث الثانوي",
  "group": "مجموعة الكيمياء A",
  "weak": [
    { "idea": "التوزيع الإلكتروني الشاذ للكروم", "lesson": "العناصر الانتقالية", "n": 3 }
  ],
  "subs": [
    { "code": "HW1", "score": 18, "total": 20, "date": "2026-10-31T12:00:00Z" }
  ],
  "quiz": { "count": 4, "correct": 17, "total": 20 }
}
```

---

## 2. Action: `quiz_new` (Generate Adaptive Quiz)
Generates an adaptive quiz from the curriculum focused on general concepts or specific weak points.

### Request Body
```json
{
  "payload": {
    "initData": "...",
    "action": "quiz_new",
    "topic": "العناصر الانتقالية",
    "count": 5
  }
}
```

### Response
```json
{
  "ok": true,
  "session_id": "c1f7a049-74d6-44a5-9bb7-9e7b99d54a21",
  "topic": "العناصر الانتقالية",
  "total": 5,
  "questions": [
    {
      "q": "أي من العناصر التالية يحتوي على تركيب إلكتروني شاذ في الحالة الذرية؟",
      "options": ["السكانديوم (Sc)", "الكروم (Cr)", "الحديد (Fe)", "الزنك (Zn)"]
    }
  ]
}
```

---

## 3. Action: `quiz_answer` (Grade Single Question)
Evaluates a single multiple-choice answer in real time, saves progress, and logs mistakes.

### Request Body
```json
{
  "payload": {
    "initData": "...",
    "action": "quiz_answer",
    "session_id": "c1f7a049-74d6-44a5-9bb7-9e7b99d54a21",
    "index": 0,
    "choice": 1
  }
}
```

### Response
```json
{
  "ok": true,
  "correct": true,
  "answer": 1,
  "explanation": "الكروم يحتوي على التوزيع 4s1 3d5 لتحقيق استقرار ذري بالامتلاء النصفي.",
  "idea": "التوزيع الإلكتروني الشاذ",
  "score": 1,
  "total": 5,
  "finished": false
}
```
