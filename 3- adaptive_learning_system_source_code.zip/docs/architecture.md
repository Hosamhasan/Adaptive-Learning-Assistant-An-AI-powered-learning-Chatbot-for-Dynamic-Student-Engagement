# System Architecture & Technical Specifications

## 1. Overview
The **Adaptive Learning System** is an AI-driven educational framework designed for high-school science curricula (Chemistry). Developed as a graduation project under the **Digital Egypt Builders / DB Industry (Ministry of Communications and Information Technology - MCIT)**, the platform integrates:
- Multimodal automated homework evaluation (vision & reasoning).
- Real-time curriculum retrieval-augmented generation (RAG).
- Automated diagnostic mistake classification.
- Dynamic adaptive quiz generation calibrated to individual knowledge gaps.

---

## 2. Core Architecture Pipeline

```text
       ┌────────────────────────┐
       │     Teacher Panel      │ (Curriculum PDF Upload & Rubrics)
       └───────────┬────────────┘
                   │
                   ▼
       ┌────────────────────────┐
       │   Curriculum RAG       │ (Recursive Chunker -> Gemini Embeddings -> pgvector)
       └───────────┬────────────┘
                   │
 ┌─────────────────┴──────────────────┐
 │                                    │
 ▼                                    ▼
┌────────────────────────┐   ┌────────────────────────┐
│  Telegram Student Bot  │   │  Telegram WebApp (API) │
│ - Question Answering   │   │ - Progress Analytics   │
│ - Homework Submissions │   │ - Adaptive Quizzes     │
│ - QuickChart Visuals   │   │ - Real-time Feedback   │
└───────────┬────────────┘   └───────────┬────────────┘
            │                            │
            └─────────────┬──────────────┘
                          ▼
            ┌────────────────────────────┐
            │   Adaptive Learning Loop   │
            │   (PostgreSQL Database)    │
            │  - students                │
            │  - homework                │
            │  - submissions             │
            │  - mistakes (weak points)  │
            │  - quiz_sessions           │
            └────────────────────────────┘
```

---

## 3. The 4 Operational Loops

### Loop A: Curriculum Knowledge Ingestion (RAG)
1. Teacher uploads curriculum chapters via n8n Form trigger (`.pdf`).
2. Documents are parsed via `PDF Loader` and chunked via `RecursiveCharacterTextSplitter` (chunk overlap: 150 chars).
3. Text chunks are vectorized using Google Gemini Embeddings (768 dimensions) and indexed into the Supabase/PostgreSQL `documents` table using HNSW cosine index.

### Loop B: Multimodal Homework Evaluation
1. Student photographs hand-written homework and sends it to the Telegram Bot.
2. Bot retrieves active homework guidelines, total marks, model answer keys, and grading rubrics.
3. Image buffer is converted to Base64 and evaluated via Gemini Vision with temperature 0.2.
4. If image quality is poor or confidence is low, submission is routed to the teacher's Telegram chat (`needs_review: true`).
5. Graded submissions update `submissions` and extract identified conceptual errors into the `mistakes` table.

### Loop C: Continuous Adaptive Diagnostic Engine
1. Every incorrect question records the concept name (`idea`), lesson, and correction.
2. When the student accesses the Mini App or requests practice:
   - The system aggregates the top frequency of errors:
     ```sql
     SELECT idea, count(*)::int AS n FROM mistakes WHERE telegram_id = $1 GROUP BY idea ORDER BY n DESC LIMIT 5;
     ```
   - RAG searches the curriculum specifically for excerpts reinforcing these exact concepts.
   - Gemini compiles targeted 4-option multiple-choice questions without answers revealed upfront.

### Loop D: Cryptographic Verification (Mini App Security)
- Telegram Mini Apps send signed `initData`.
- The webhook verifies authenticity without relying on external Node packages using pure JavaScript **Ed25519 & SHA-512** cryptographic algorithms directly inside n8n.
